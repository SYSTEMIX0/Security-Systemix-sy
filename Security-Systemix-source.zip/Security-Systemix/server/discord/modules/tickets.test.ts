import { readFile } from "node:fs/promises";
import { ChannelType } from "discord.js";
import { describe, expect, it } from "vitest";
import { canManageTicket, cleanTicketChannelName, findConfiguredActiveTicketCategory, findConfiguredTicketPanelCategory, isUsableTicketSupportRole, normalizeTicketCloseReason, TICKET_CLOSE_REASON_MAX_LENGTH, ticketChannelPrefix, ticketLifecycleLogFields, ticketPanelChannelName } from "./tickets";
import { defaultGuildSecurityConfig } from "../config";

describe("ticket safety helpers", () => {
  it("only lets opener or staff close a ticket", () => {
    expect(canManageTicket("opener", "opener", false)).toBe(true);
    expect(canManageTicket("other", "opener", false)).toBe(false);
    expect(canManageTicket("staff", "opener", true)).toBe(true);
  });

  it("requires a bounded non-empty close reason without control characters", () => {
    expect(normalizeTicketCloseReason("  تم حل المشكلة\n\nبعد التأكيد  ")).toBe("تم حل المشكلة بعد التأكيد");
    expect(normalizeTicketCloseReason("\u0000 \n\t")).toBeNull();
    expect(normalizeTicketCloseReason("أ".repeat(TICKET_CLOSE_REASON_MAX_LENGTH + 20))).toHaveLength(TICKET_CLOSE_REASON_MAX_LENGTH);
  });

  it("normalizes channel names and falls back when no safe characters remain", () => {
    expect(cleanTicketChannelName("Ticket: Foo / Bar" )).toBe("ticket-foo-bar");
    expect(cleanTicketChannelName("🔥🔥")).toBe("ticket");
    expect(cleanTicketChannelName("A".repeat(80))).toHaveLength(40);
  });

  it("uses a clear and stable channel prefix for each supported ticket type", () => {
    expect(ticketChannelPrefix("open-ticket")).toBe("open-ticket");
    expect(ticketChannelPrefix("middleman-ticket")).toBe("middleman-ticket");
    expect(ticketChannelPrefix("levelup-ticket")).toBe("levelup-ticket");
  });

  it("uses one fixed panel channel per ticket type", () => {
    expect(ticketPanelChannelName("open-ticket")).toBe("🎫・open-ticket");
    expect(ticketPanelChannelName("middleman-ticket")).toBe("🤝・middleman-ticket");
    expect(ticketPanelChannelName("levelup-ticket")).toBe("📈・levelup-ticket");
  });

  it("uses only an unmanaged support role below the bot's highest role", () => {
    expect(isUsableTicketSupportRole({ managed: false, position: 4 } as never, 5)).toBe(true);
    expect(isUsableTicketSupportRole({ managed: false, position: 5 } as never, 5)).toBe(false);
    expect(isUsableTicketSupportRole({ managed: false, position: 6 } as never, 5)).toBe(false);
    expect(isUsableTicketSupportRole({ managed: true, position: 1 } as never, 5)).toBe(false);
  });

  it("captures a select value before React schedules its state update", async () => {
    const source = await readFile("client/src/components/ProtectionConsole.tsx", "utf8");
    expect(source).toContain('const mode = event.currentTarget.value as GuildSecurityConfig["mode"];');
    expect(source).toContain("setDraft((current) => current ? { ...current, mode } : current);");
  });

  it("keeps the guided ticket setup command with an explicit support-role", async () => {
    const source = await readFile("server/discord/modules/tickets.ts", "utf8");
    expect(source).toContain('sub.setName("setup")');
    expect(source).toContain('option.setName("support-role")');
    expect(source).toContain('ticketCommand("systemix-tickets")');
    expect(source).toContain('customId("tickets", "open", topic.id)');
    expect(source).toContain("ACTIVE_TICKETS_CATEGORY_NAME");
    expect(source).toContain("MANAGED_SUPPORT_ROLE_NAME");
    expect(source).toContain("TICKET_BOT_CHANNEL_PERMISSIONS");
    expect(source).toContain("PermissionFlagsBits.EmbedLinks");
    expect(source).toContain("ensurePublicTicketPanelPermissions(center, guild.id, me.id)");
    expect(source).toContain("SendMessages: false");
  });

  it("creates a configurable ticket centre and records lifecycle events without ticket text", async () => {
    const source = await readFile("server/discord/modules/tickets.ts", "utf8");
    expect(source).toContain('TICKET_CENTER_CHANNEL_NAME = "🎟️・ticket-center"');
    expect(source).toContain("new StringSelectMenuBuilder()");
    expect(source).toContain("writeTicketLifecycleLog");
    expect(source).toContain('eventType: "opened"');
    expect(source).toContain('eventType: "claimed"');
    expect(source).toContain('eventType: "closed"');
    expect(source).toContain('customId("tickets", "closemodal", arg)');
    expect(source).toContain('customId("tickets", "closeconfirm", ticket.id, nonce)');
    expect(source).toContain("createPendingTicketClose");
    expect(source).toContain("consumePendingTicketClose");
    expect(source).toContain("finishTicketClose(guild.id, ticket.id, member.id, closeReason, closedAt)");
    expect(source).toContain("onModal,");
    expect(source).not.toContain('closeReason: "إغلاق يدوي من لوحة التذكرة"');
    const componentHandler = source.slice(source.indexOf("async function onComponent"), source.indexOf("async function onModal"));
    expect(componentHandler.indexOf("interaction.showModal(modal)")).toBeLessThan(componentHandler.indexOf("await deferTicketReply(interaction)"));
  });

  it("formats a compact reference-style Arabic closing card without retaining ticket conversation text", () => {
    const fields = ticketLifecycleLogFields({
      guild: {} as never,
      config: defaultGuildSecurityConfig,
      eventType: "closed",
      actorId: "closer-id",
      openerId: "opener-id",
      ticketId: 99,
      ticketNumber: 12,
      channelId: "channel-id",
      channelDeleted: true,
      topic: "technical-support",
      openedAt: new Date("2026-10-26T10:00:00.000Z"),
      closedAt: new Date("2026-10-26T10:30:00.000Z"),
      closeReason: "انتهاء الطلب",
      claimedById: "claimer-id",
    });
    expect(fields).toEqual(expect.arrayContaining([
      expect.objectContaining({ name: "تم الفتح بواسطة", value: "<@opener-id>", inline: true }),
      expect.objectContaining({ name: "تم الاستلام بواسطة", value: "<@claimer-id>", inline: true }),
      expect.objectContaining({ name: "تم الإغلاق بواسطة", value: "<@closer-id>", inline: true }),
      expect.objectContaining({ name: "وقت الفتح", inline: true }),
      expect.objectContaining({ name: "وقت الإغلاق", inline: true }),
      expect.objectContaining({ name: "سبب الإغلاق", value: expect.stringContaining("انتهاء الطلب"), inline: false }),
    ]));
    expect(fields).toHaveLength(6);
    expect(fields.find((field) => field.name === "سبب الإغلاق")?.value).toContain("```ansi");
    expect(JSON.stringify(fields)).not.toContain("محتوى المحادثة");
  });

  it("repairs the ticket opener's explicit channel access after creation and on a repeat click", async () => {
    const source = await readFile("server/discord/modules/tickets.ts", "utf8");
    expect(source).toContain("listOpenTickets(guild.id, member.id)");
    expect(source).toContain("await ensureTicketMemberChannelPermissions(channel, member.id)");
    expect(source).toContain("await ensureTicketMemberChannelPermissions(existingChannel, member.id)");
  });

  it("exports a bounded transcript before channel deletion and keeps attachment URLs out of storage", async () => {
    const source = await readFile("server/discord/modules/tickets.ts", "utf8");
    expect(source).toContain("const TRANSCRIPT_MESSAGE_LIMIT = 500");
    expect(source).toContain("if (cfg.transcriptEnabled)");
    expect(source).toContain("saveTicketTranscript(guild.id, ticket.id, transcript)");
    expect(source.indexOf("saveTicketTranscript(guild.id, ticket.id, transcript)")).toBeLessThan(source.indexOf('ticketChannel.delete("Ticket closed through Security Systemix")'));
    expect(source).toContain("attachment.name ?? \"مرفق\"");
    expect(source).not.toContain("attachment.url");
    expect(source).toContain('setLabel("عرض التذكرة").setStyle(ButtonStyle.Link)');
  });

  it("uses the Systemix ticket artwork and guild identity in lifecycle log cards", async () => {
    const source = await readFile("server/discord/modules/tickets.ts", "utf8");
    expect(source).toContain('"/systemix-ticket-archive-thumbnail.png"');
    expect(source).toContain("embed.setAuthor");
    expect(source).toContain("Ticket Logs");
  });

  it("avoids reusing a ticket category hidden from the bot", async () => {
    const source = await readFile("server/discord/modules/tickets.ts", "utf8");
    expect(source).toContain("hasTicketCategoryAccess(channel, member)");
    expect(source).toContain("PermissionFlagsBits.ViewChannel");
  });

  it("prefers the configured panel and active categories even after they are renamed", () => {
    const panelCategory = { id: "saved-panel-category", type: ChannelType.GuildCategory, permissionsFor: () => ({ has: () => true }) };
    const activeCategory = { id: "saved-active-category", type: ChannelType.GuildCategory, permissionsFor: () => ({ has: () => true }) };
    const center = { id: "saved-center", parentId: panelCategory.id };
    const guild = { channels: { cache: new Map([[panelCategory.id, panelCategory], [activeCategory.id, activeCategory], [center.id, center]]) } } as never;
    const config = {
      ...defaultGuildSecurityConfig,
      tickets: { ...defaultGuildSecurityConfig.tickets, panelChannelId: center.id, categoryId: activeCategory.id },
    };
    expect(findConfiguredTicketPanelCategory(guild, {} as never, config)).toBe(panelCategory);
    expect(findConfiguredActiveTicketCategory(guild, {} as never, config)).toBe(activeCategory);
  });

  it("fetches the bot member after a fresh invite when the Gateway member cache is empty", async () => {
    const source = await readFile("server/discord/modules/tickets.ts", "utf8");
    expect(source).toContain("guild.members.fetchMe()");
    expect(source).toContain("await resolveBotMember(guild)");
  });
});
